//
//  ContentView.swift
//  TaipeiTour
//
//  Created by Steve Lai on 2021/7/26.
//

import SwiftUI

struct Places: Codable {
    var total: Int
    var data: [Place]
    struct Place: Codable {
        var id: Int
        var name: String
        var address: String
    }
}


struct ContentView: View {
    @State var places: Places?
    @State var result: String = ""
    var body: some View {
        if let places = places{
            List(places.data, id:\.id){ item in
                HStack {
                    Text(item.name)
                        .multilineTextAlignment(.center)
                        .frame(maxWidth: .infinity)
                        .padding()
                        
                    Text(item.address)
                        .frame(maxWidth: .infinity)
                        .padding()
                }
            }
        }
        Text(result)
            .onAppear(perform: self.loadData)
        
    }
    
    
    func loadData(){
        //        self.result = "Test"
        
        let urlString = "https://www.travel.taipei/open-api/zh-tw/Attractions/All?categoryIds=12&page=1"
        
        guard let url = URL(string: urlString) else {
            print("Illegle URL")
            return
        }
        
        var request = URLRequest(url: url)
        request.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Accept")
        request.httpMethod = "GET"
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                fatalError(error.localizedDescription)
            }
            
            guard let data = data else{
                return
            }
            
            do {
                let places = try JSONDecoder().decode(Places.self, from: data)
                DispatchQueue.main.async {
                    self.places = places
                }
            } catch let error {
                print(error.localizedDescription)
            }
//            if let data = data{
//                DispatchQueue.main.async{
//
//                }
//            }
        }.resume()
        
    }
}



struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
