//
//  WebViewController.swift
//  TourRandom
//
//  Created by Steve Lai on 2018/5/2.
//  Copyright © 2018年 plusForm. All rights reserved.
//

import UIKit
import WebKit

class WebViewController: UIViewController {

    @IBOutlet weak var webView: WKWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if let url = URL(string: "https://www.travel.taipei/zh-tw"){
            let request = URLRequest(url: url)
            webView.load(request)
        }
        
       
    }

}
