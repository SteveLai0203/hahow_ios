//
//  ViewController.swift
//  TourRandom
//
//  Created by Steve Lai on 2018/5/2.
//  Copyright © 2018年 plusForm. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.setNavigationBarHidden(true, animated: animated)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        self.navigationController?.setNavigationBarHidden(false, animated: animated)
    }

    @IBAction func webBtn(_ sender: Any) {
        
    }
    
    @IBAction func tourBtn(_ sender: Any) {
        let detialVC = storyboard?.instantiateViewController(withIdentifier: "DetialVC") as! DetialViewController
        let btn = sender as! UIButton
        if let str = btn.titleLabel?.text {
            detialVC.cate = str
            navigationController?.pushViewController(detialVC, animated: true)
        }
    }
    
    
}

