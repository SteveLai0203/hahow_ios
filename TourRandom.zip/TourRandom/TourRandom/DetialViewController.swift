//
//  DetialViewController.swift
//  TourRandom
//
//  Created by Steve Lai on 2018/5/2.
//  Copyright © 2018年 plusForm. All rights reserved.
//

import UIKit
import MapKit

class DetialViewController: UIViewController {

    @IBOutlet weak var naviTitle: UINavigationBar!
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var textView: UITextView!
    
    var cate = ""
    var pointsArray = [Places.Place.Point]()
    
    struct Places: Codable {
        var result: Place
        struct Place: Codable {
            var results: [Point]
            struct Point: Codable {
                var stitle: String
                var CAT2: String
                var longitude: String
                var latitude: String
                var xbody: String
                var address: String
            }
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func getData() {
        print("test")
        let url = URL(string: "http://data.taipei/opendata/datalist/apiAccess?scope=resourceAquire&rid=36847f3f-deff-4183-a5bb-800737591de5")

        URLSession.shared.dataTask(with: url!) { (data, reponse, error) in
            if let errorDes = error{
                print(errorDes.localizedDescription)
            }
            
            do {
                if let data = data {
                    let pointData = try JSONDecoder().decode(Places.self, from: data)
                    for point in pointData.result.results{
                        if self.cate == point.CAT2 {
                            self.pointsArray.append(point)
                        }
                    }
//                    print(self.pointsArray
                }
                DispatchQueue.main.async {
                    let randomNum = Int(arc4random_uniform(UInt32(self.pointsArray.count)))
                    let po = self.pointsArray[randomNum]
                    self.naviTitle.topItem?.title = po.stitle
                    self.textView.text = po.xbody
                    
                    let location = CLLocation(latitude: Double(po.latitude)!, longitude: Double(po.longitude)!)
                    self.centerMapOnLocation(location: location)
                    let pin = MKPointAnnotation()
                    pin.coordinate = location.coordinate
                    pin.title = po.address
                    self.mapView.addAnnotation(pin)
                    
                }
            }catch let jsonError{
                print(jsonError)
            }
            

        }.resume()
    }
    
    func centerMapOnLocation(location: CLLocation) {
        let region = MKCoordinateRegionMakeWithDistance(location.coordinate, 1000, 1000)
        mapView.setRegion(region, animated: true)
    }

}
