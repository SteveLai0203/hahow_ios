//
//  SignUpViewController.swift
//  InstaClone
//
//  Created by Steve Lai on 2018/5/6.
//  Copyright © 2018年 plusForm. All rights reserved.
//

import UIKit
import Firebase
//import FirebaseAuth

class SignUpViewController: UIViewController {
    
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    @IBOutlet weak var confirePasswordField: UITextField!
    

    @IBOutlet weak var skipBtn: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        skipBtn.layer.cornerRadius = 8
        // Do any additional setup after loading the view.
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func createACPressed(_ sender: Any) {
        if let email = emailTextField.text, let password = passwordField.text , let confirmPassword = confirePasswordField.text{
            if password == confirmPassword{
                Auth.auth().createUser(withEmail: email, password: password) { (authResult, error) in
                    if let error = error {
                        print(error.localizedDescription)
                        return
                    }
                    if let email = authResult?.user.email {
                        print("\(email) created")
                    }
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "TabBarVC")
                    self.present(vc!, animated: true, completion: nil)
                }
            }
            else {
                print("Password didn't math")
            }
        }else{
            print("Field can't empty")
        }

        
        
        
        
    }
    

}
