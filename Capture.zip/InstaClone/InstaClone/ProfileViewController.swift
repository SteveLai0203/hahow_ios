//
//  ProfileViewController.swift
//  InstaClone
//
//  Created by Steve Lai on 2018/5/6.
//  Copyright © 2018年 plusForm. All rights reserved.
//

import UIKit
import Firebase

class ProfileViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let titleView = UIImageView(image: UIImage(named: "titleLogo"))
        self.navigationItem.titleView = titleView
    }
    
    
    @IBAction func logoutPressed(_ sender: Any) {
        let firebaseAuth = Auth.auth()
        do {
            try firebaseAuth.signOut()
            let signIn = self.storyboard?.instantiateViewController(withIdentifier: "loginVC")
            let delegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate
            delegate.window?.rootViewController = signIn
        } catch let signOutError as NSError {
            print ("Error signing out: %@", signOutError)
        }
    }

}
