//
//  ViewController.swift
//  InstaClone
//
//  Created by Steve Lai on 2018/5/4.
//  Copyright © 2018年 plusForm. All rights reserved.
//

import UIKit
//6.3 遠端參數
import Firebase
//import FirebaseAuth

class ViewController: UIViewController {

    @IBOutlet weak var signUpBtn: UIButton!
    @IBOutlet weak var facebookLoginBtn: UIButton!
    @IBOutlet weak var googleLoginBtn: UIButton!
    @IBOutlet weak var emailField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    
    //6.3 遠端參數 2
    let facebookEnableKey = "FacebookLoginEnable"
    let googleEnableKey = "GoogleLoginEnable"
    var remoteConfig: RemoteConfig!
    
    //6.4 帳號註冊 1
    var handle: AuthStateDidChangeListenerHandle?

    
    
    let yourAttributes : [NSAttributedStringKey: Any] = [
        NSAttributedStringKey.font : UIFont.systemFont(ofSize: 14),
        NSAttributedStringKey.foregroundColor : UIColor.white,
        NSAttributedStringKey.underlineStyle : NSUnderlineStyle.styleSingle.rawValue]
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        self.setNeedsStatusBarAppearanceUpdate()
        
        let attributeString = NSMutableAttributedString(string: "Create an account", attributes: yourAttributes)
        signUpBtn.setAttributedTitle(attributeString, for: .normal)
        //6.3 遠端參數 3
        remoteConfig = RemoteConfig.remoteConfig()
        let remoteConfigSettings = RemoteConfigSettings(developerModeEnabled: true)
        remoteConfig.configSettings = remoteConfigSettings
        
        remoteConfig.setDefaults(fromPlist: "RemoteConfig")
        
        fetchConfig()
        
    }
    
    // MARK: - Listen for authentication state
    //6.4 帳號註冊 1
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        // [START auth_listener]
        handle = Auth.auth().addStateDidChangeListener { (auth, user) in
            // [START_EXCLUDE]
//            self.setTitleDisplay(user)
//            self.tableView.reloadData()
            // [END_EXCLUDE]
        }
        // [END auth_listener]
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        // [START remove_auth_listener]
        Auth.auth().removeStateDidChangeListener(handle!)
        // [END remove_auth_listener]
    }
    
    func fetchConfig(){
        var expirationDuration = 3600
        
        if remoteConfig.configSettings.isDeveloperModeEnabled {
            expirationDuration = 0
        }
        
        remoteConfig.fetch(withExpirationDuration: TimeInterval(expirationDuration)) { (status, error) -> Void in
            if status == .success {
                print("Config fetched!")
                self.remoteConfig.activateFetched()
            } else {
                print("Config not fetched")
                print("Error: \(error?.localizedDescription ?? "No error available.")")
            }
            self.showLogin()
        }

    }
    
    func showLogin(){
        let enableFBLogin = remoteConfig[facebookEnableKey].boolValue
        facebookLoginBtn.isHidden = !enableFBLogin
        let enableGoogleLogin = remoteConfig[googleEnableKey].boolValue
        googleLoginBtn.isHidden = !enableGoogleLogin
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func loginBtn(_ sender: Any) {
        //6.3 遠端參數 1
//        Analytics.logEvent("LoginButton", parameters: nil)
        
        if let email = emailField.text, let password = passwordField.text{
            Auth.auth().signIn(withEmail: email, password: password) { (user, error) in
                if let error = error {
                    print(error.localizedDescription)
                    return
                }
                self.performSegue(withIdentifier: "login", sender: sender)
            }
        }else{
            print("Can't be empty!")
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
}

