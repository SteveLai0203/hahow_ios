//
//  UploadViewController.swift
//  InstaClone
//
//  Created by Steve Lai on 2018/5/6.
//  Copyright © 2018年 plusForm. All rights reserved.
//

import UIKit
import Firebase
import FirebaseStorage

class UploadViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    @IBOutlet weak var statusLabel: UILabel!
    @IBOutlet weak var ImageView: UIImageView!
    @IBOutlet weak var postField: UITextView!
    var storage = Storage.storage()
    let picker = UIImagePickerController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        picker.delegate = self
        statusLabel.text = "Tap pics to select from photo library"
        if let _ = ImageView.image {
            statusLabel.text = "Have image"
        }
        else{
//            if UIImagePickerController.isSourceTypeAvailable(.camera) {
//                picker.sourceType = .camera
//            } else {
//                picker.sourceType = .photoLibrary
//            }
            picker.sourceType = .photoLibrary

            
            present(picker, animated: true, completion:nil)
        }
        
        let tapGesture = UITapGestureRecognizer(target:self, action:#selector(UploadViewController.imagePressed))
        ImageView.isUserInteractionEnabled = true // this line is important
        ImageView.addGestureRecognizer(tapGesture)

        // Do any additional setup after loading the view.
    }
    
    @objc func imagePressed() {
        picker.sourceType = .photoLibrary
        present(picker, animated: true, completion:nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController,
                               didFinishPickingMediaWithInfo info: [String : Any]) {
        
//        if let _ = self.ImageView.image {
//            let image = info[UIImagePickerControllerEditedImage] as? UIImage
//            print("Edit")
//            ImageView.image = image
//        }else {
            let image = info[UIImagePickerControllerOriginalImage] as? UIImage
            ImageView.image = image
//        }
        
        picker.dismiss(animated: true, completion:nil)
    }

    @IBAction func camerPressed(_ sender: Any) {
        

        picker.sourceType = .camera
        present(picker, animated: true, completion:nil)
    }
    
    @IBAction func sharePressed(_ sender: Any) {
        statusLabel.text = "Beginning Upload"
        if let image = ImageView.image {
            guard let imageData = UIImageJPEGRepresentation(image, 0.8) else { return }

            let imagePath = Auth.auth().currentUser!.uid + "/media/\(Int(Date.timeIntervalSinceReferenceDate * 1000)).jpg"
            let metadata = StorageMetadata()
            metadata.contentType = "image/jpeg"
            let storageRef = self.storage.reference(withPath: imagePath)
            storageRef.putData(imageData, metadata: metadata) { (metadata, error) in
                if let error = error {
                    print("Error uploading: \(error)")
                    self.statusLabel.text = "Upload Failed"
                    return
                }
                self.statusLabel.text = "Upload Succeeded"
//                let imageURL = metadata?.downloadURL()?.absoluteString
                storageRef.downloadURL(completion: { (url, error) in
                    if let error = error{
                        print(error.localizedDescription)
                    }
                    if let imageURL = url?.absoluteString{
                        print(imageURL)
                        let post = ["image" : imageURL, "postedBy" : Auth.auth().currentUser!.email!, "postText": self.postField.text] as [String: Any]
                        Database.database().reference().child("users").child(Auth.auth().currentUser!.uid).child("posts").childByAutoId().setValue(post)
                    }
                })
//                print(imageURL!)
                
//                let post = ["image" : imageURL!, "postedBy" : Auth.auth().currentUser!.email!, "postText": self.postField.text] as [String: Any]
//
//                Database.database().reference().child("users").child(Auth.auth().currentUser!.uid).child("posts").childByAutoId().setValue(post)
                
            }
        }
    }
}
