//
//  FeedViewController.swift
//  InstaClone
//
//  Created by Steve Lai on 2018/5/6.
//  Copyright © 2018年 plusForm. All rights reserved.
//

import UIKit
import Firebase
import Alamofire
import AlamofireImage

class FeedViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tableView: UITableView!
    
    var userEmailArray = [String]()
    var postCommentArray = [String]()
    var imageURLArray = [String]()
    var storageRef: StorageReference!
    let refreshControl = UIRefreshControl()

    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
//        self.tableView.estimatedRowHeight = 500

        getDataFromFirebase()
        tableView.refreshControl = refreshControl
        refreshControl.addTarget(self, action: #selector(refreshWeatherData(_:)), for: .valueChanged)

        // Do any additional setup after loading the view.
    }
    
    @objc func refreshWeatherData(_ sender: Any) {
        // Fetch Weather Data
        fetchWeatherData()
    }
    
    private func fetchWeatherData() {
        userEmailArray.removeAll()
        postCommentArray.removeAll()
        imageURLArray.removeAll()
        getDataFromFirebase()

    }
    
    func getDataFromFirebase() {
//        Database.database().reference().child("users").child(uid!).child("posts").observe(.childAdded) { (snapshot) in
//            let value = snapshot.value as! NSDictionary
//            print(value)
//        }
        Database.database().reference().child("users").observe(.childAdded) { (snapshot) in
            let value = snapshot.value as! NSDictionary
            let posts = value["posts"] as! NSDictionary
            let postID = posts.allKeys
            for id in postID {
                let singlePost = posts[id] as! NSDictionary
                self.userEmailArray.append(singlePost["postedBy"] as! String)
                self.postCommentArray.append(singlePost["postText"] as! String)
                self.imageURLArray.append(singlePost["image"] as! String)
            }
            DispatchQueue.main.async {

                self.tableView.reloadData()
                self.refreshControl.endRefreshing()

            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let titleView = UIImageView(image: UIImage(named: "titleLogo"))
        self.navigationItem.titleView = titleView
        
    }

    
    @IBAction func logoutPressed(_ sender: Any) {
        let firebaseAuth = Auth.auth()
        do {
            try firebaseAuth.signOut()
            let signIn = self.storyboard?.instantiateViewController(withIdentifier: "loginVC")
            let delegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate
            delegate.window?.rootViewController = signIn
        } catch let signOutError as NSError {
            print ("Error signing out: %@", signOutError)
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return userEmailArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let cell: UITableViewCell
        cell = tableView.dequeueReusableCell(withIdentifier: "postCell", for: indexPath)
        if let postCell = cell as? PostTableViewCell{
            
            postCell.postText.text = postCommentArray[indexPath.row]
            postCell.userName.text = userEmailArray[indexPath.row]
            let filePath = imageURLArray[indexPath.row]
            Alamofire.request(filePath).responseImage { response in
                if let image = response.result.value {
                    let size = CGSize(width: 375.0, height: 275.0)
                    let aspectScaledToFitImage = image.af_imageAspectScaled(toFit: size)
                    postCell.postImage.image = aspectScaledToFitImage
                }
            }
            
            return postCell
        }
        return cell
    }
    
    
    
//    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
//        return UITableViewAutomaticDimension
//    }
//
//    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
//        return UITableViewAutomaticDimension
//    }
    

}
