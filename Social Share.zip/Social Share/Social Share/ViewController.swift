//
//  ViewController.swift
//  Social Share
//
//  Created by Steve Lai on 2018/5/3.
//  Copyright © 2018年 plusForm. All rights reserved.
//

import UIKit
import Social

class ViewController: UIViewController {

    @IBOutlet weak var facebookTextView: UITextView!
    @IBOutlet weak var tweetTextView: UITextView!
    @IBOutlet weak var moreTextView: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configTextView()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    func configTextView() {
        facebookTextView.layer.cornerRadius = 10.0
        facebookTextView.layer.borderWidth = 2.0
        facebookTextView.layer.borderColor = UIColor(white: 0, alpha: 0.5).cgColor
        facebookTextView.text = "This is for facebook share!"
        
        tweetTextView.layer.cornerRadius = 10.0
        tweetTextView.layer.borderWidth = 2.0
        tweetTextView.layer.borderColor = UIColor(white: 0, alpha: 0.5).cgColor
        tweetTextView.text = "This is for twitter share!"
        
        moreTextView.layer.cornerRadius = 10.0
        moreTextView.layer.borderWidth = 2.0
        moreTextView.layer.borderColor = UIColor(white: 0, alpha: 0.5).cgColor
        moreTextView.text = "This is for sharing!"
    }
    
    @IBAction func sharePressed(_ sender: UIBarButtonItem) {
        if sender.tag == 0{
            if let vc = SLComposeViewController(forServiceType: SLServiceTypeFacebook){
                vc.setInitialText(facebookTextView.text)
                present(vc, animated: true, completion: nil)
            }
        }else{
            if let vc = SLComposeViewController(forServiceType: SLServiceTypeTwitter){
                vc.setInitialText(tweetTextView.text)
                present(vc, animated: true, completion: nil)
            }
            
        }
    }
    
    @IBAction func moreShare(_ sender: Any) {
        let vc = UIActivityViewController(activityItems: [moreTextView.text], applicationActivities: [])
        present(vc, animated: true, completion: nil)
    }
    
    @IBAction func nothingAlert(_ sender: Any) {
        let alert = UIAlertController(title: "Alert", message: "Do nothing, just a alert!", preferredStyle: .alert)
        let action = UIAlertAction(title: "OK", style: .default, handler: nil)
        let action2 = UIAlertAction(title: "Cancel", style: .destructive, handler: nil)
        
        alert.addAction(action2)
        alert.addAction(action)
        
        present(alert, animated: true, completion: nil)
    }
    

}

