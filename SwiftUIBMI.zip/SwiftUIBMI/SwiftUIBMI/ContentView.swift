//
//  ContentView.swift
//  SwiftUIBMI
//
//  Created by Steve Lai on 2021/7/12.
//

import SwiftUI

struct ContentView: View {
    @State private var result: String = "BMI Result"
    //    @State private var isEditing = false
    @State private var heightInput = ""
    @State private var weightInput = ""
    @State private var height: Double = 0
    @State private var weight: Double = 0
    var body: some View {
        VStack{
            HStack{
                TextField("Height", text: $heightInput)
                    //                    {isEditing in self.isEditing = isEditing}
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .keyboardType(.numbersAndPunctuation)
                TextField("Weight", text: $weightInput)
                    //                    {isEditing in self.isEditing = isEditing}
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .keyboardType(.numbersAndPunctuation)
            }.padding()
            
            Text(result)
                .font(.title)
                .fontWeight(.bold)
                .foregroundColor(Color.purple)
                .padding()
            Divider()
            Button("Caculate!",
                   action: {
                    if let height = Double(self.heightInput), let weight = Double(self.weightInput){
                        
//                        self.result = String(format: "Your BMI is %.2f", calBMI(height, weight))
                        let format = NumberFormatter()
                        format.numberStyle = .decimal
                        format.maximumFractionDigits = 2
                        
                        if let result = format.string(from: NSNumber(value: calBMI(height, weight))){
                            self.result = result
                        }
                    }
                   })
                .foregroundColor(.red)
                .padding()
                .overlay(
                    RoundedRectangle(cornerRadius: 40)
                        .stroke(Color.white, lineWidth: 2)
                )
            Spacer()
        }
        .background(
            Image("BG")
                .resizable()
                .aspectRatio(contentMode: .fill)
                .edgesIgnoringSafeArea(.all)
                .blur(radius: 3.0)
            //                .grayscale(0.9)
            
        )
    }
}

func calBMI(_ height: Double, _ weight: Double) -> Double{
    let h: Double = height / 100
    let w: Double = weight
    return w / pow(h, 2)
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
