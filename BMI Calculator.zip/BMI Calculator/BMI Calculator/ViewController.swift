//
//  ViewController.swift
//  BMI Calculator
//
//  Created by Steve Lai on 2018/5/1.
//  Copyright © 2018年 plusForm. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var hightField: UITextField!
    @IBOutlet weak var weightField: UITextField!
    @IBOutlet weak var BMILabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        BMILabel.text = "BMI："
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func calBMI(_ sender: Any) {
        
        if let height = Double(hightField.text!), let weight = Double(weightField.text!){
            let bmi = weight / ((height/100) * (height/100))
            BMILabel.text = String(format: "您的BMI是%.2f", bmi)
        }
//        let height = Double(hightField.text!)
//        let weight = Double(weightField.text!)
//        let bmi = weight! / ((height!/100) * (height!/100))
        
        //print(bmi)
        //BMILabel.text = String(format: "您的BMI是%.2f", bmi)
    }
    
}

