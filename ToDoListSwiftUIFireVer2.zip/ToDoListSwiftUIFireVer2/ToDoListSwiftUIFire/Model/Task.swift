//
//  File.swift
//  ToDoListSwiftUIFire
//
//  Created by Steve Lai on 2021/7/26.
//

import Foundation
import FirebaseFirestore
import FirebaseFirestoreSwift

struct Task: Codable, Identifiable {
    @DocumentID var id: String?
    var title:String
    var completed: Bool
    @ServerTimestamp var createdTime: Timestamp?
}


#if DEBUG

let testDataTasks = [
    Task(title: "Buy Milk", completed: true),
    Task(title: "學習 iOS", completed: false),
    Task(title: "????", completed: false),
    Task(title: "Get apple before home", completed: false)
]

#endif
