//
//  ViewController.swift
//  CoreMLTest
//
//  Created by Steve Lai on 2018/5/10.
//  Copyright © 2018年 plusForm. All rights reserved.
//

import UIKit
import CoreML
import Vision

class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var chooseBtn: UIButton!
    @IBOutlet weak var resultLabel: UILabel!
    let picker = UIImagePickerController()
    var chooseImage = CIImage()

    override func viewDidLoad() {
        super.viewDidLoad()
        picker.delegate = self

        chooseBtn.layer.cornerRadius = 5
        if let image = CIImage(image: imageView.image!) {
            reconizeImage(image: image)
        }
        
    }

    @IBAction func chooseFile(_ sender: Any) {
        fromWhereAlert()
    }
    
    func fromWhereAlert() {
        let alert = UIAlertController(title: "Souce", message: "Where is your picture", preferredStyle: .alert)
        let camera = UIAlertAction(title: "Camera", style: .default, handler: {
            (action) in
            self.picker.sourceType = .camera
            self.present(self.picker, animated: true, completion:nil)

            
        })
        let photoLib = UIAlertAction(title: "Photo Library", style: .default, handler: {(action) in
            self.picker.sourceType = .photoLibrary
            self.present(self.picker, animated: true, completion:nil)
            
        })
        
        alert.addAction(camera)
        alert.addAction(photoLib)
        alert.addAction(UIAlertAction(title:"Cancel", style: .cancel, handler: nil))
        
        present(alert, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        let image = info[UIImagePickerControllerOriginalImage] as? UIImage
        imageView.image = image
        picker.dismiss(animated: true, completion:nil)
        if let image = CIImage(image: image!) {
            reconizeImage(image: image)
        }
       
    }
    
    func reconizeImage(image: CIImage) {
        resultLabel.text = "reconizing..."
        if let  model = try? VNCoreMLModel(for: VGG16().model) {
            let request = VNCoreMLRequest(model: model, completionHandler: { (request, error) in
                if let results = request.results as? [VNClassificationObservation]{
                    let topResult = results.first
                    
                    DispatchQueue.main.async {
                        let conf = (topResult?.confidence)! * 100
                        let rounded = Int( conf * 100) / 100
                        self.resultLabel.text = "\(rounded)% it's \(topResult!.identifier)"
                    }
                }
            })
            
            let handler = VNImageRequestHandler(ciImage: image)
            DispatchQueue.global(qos: .userInteractive).async {
                do{
                    try handler.perform([request])
                }catch {
                    print("error")
                }
            }
            
        }
        
    }
    

}

